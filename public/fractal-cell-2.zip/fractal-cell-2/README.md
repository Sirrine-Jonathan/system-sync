# Fractal Cell 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/alexr4/pen/dgXGdv](https://codepen.io/alexr4/pen/dgXGdv).

